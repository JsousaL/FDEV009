ALGORITMOS - PASSO A PASSO
É UMA SEQUENCIA LOGICA PARA RESOLVER UM DETERMINADO PROBLEMA.

COMPRAR CHOCOLATE NA PAGUE MENOS
- SAIR DA ESCOLA
- ENTRAR NA LOJA PAGUE MENOS
- ESCOLHER O CHOCOLATE
- PEGAR O CHOCOLATE
- IR NO CAIXA
- PAGAR COM DEBITO
- SAIR DA FARMACIA
- IR PARA ESCOLA

PSEUDOCODIGO
Pseudocódigo é uma forma de representar algoritmos, funções ou outros processos de forma simplificada e intuitiva. 
Ele é escrito em uma linguagem natural e elementos que se assemelham a uma linguagem de programação, mas não é realmente executável.


PROCESSOS;
ENTRADA, PROCESSAMENTO E SAÍDA.